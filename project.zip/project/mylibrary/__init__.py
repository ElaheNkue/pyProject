# -*- coding: utf-8 -*-
"""
Created on Mon May 11 12:29:31 2026

@author: e.nekoei
"""

