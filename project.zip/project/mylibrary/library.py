class Library:
    
    def __init__(self):
        self.books = []

    def add_book(self, title, author):
        book = {
            "title" : title,
            "author" : author
               }
        self.books.append(book)
        print(f"{title} added")


    def remove_book(self, title):
      
        for book in self.books:
            if book["title"] == title:
                self.books.remove(book)
                print(f"{title} removed")

    def search_book(self, title):
        
      for book in self.books:
          if book["title"]== title:
              print (f"{book['title']} : {book['author']}")
          else:
              print("Not found")
              

    def show_books(self):
        if not self.books:
            print("There is no Book")
        for book in self.books:
            print(f"{book['title']} - {book['author']}")
        
                
                
            
            
      


    