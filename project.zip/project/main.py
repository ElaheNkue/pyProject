# -*- coding: utf-8 -*-
"""
Created on Mon May 11 12:26:05 2026

@author: e.nekoei
"""

from mylibrary.library import Library
library = Library()


if __name__ == "__main__":
    while True:

        print("\n===== Library Manegement System =====")
        print("1. Add a Book")
        print("2. Delete a Book")
        print("3. Find a Book")
        print("4. Show all Books")
        print("5. Exit")
        
        
        choice = input("Choose a number: ")

        if choice == "1":

            title = input("Title: ")
            author = input("AutorName: ")

            library.add_book(title, author)

        elif choice == "2":

            title = input("Title for delete: ")
            library.remove_book(title)

        elif choice == "3":

            title = input("Title for search: ")
            library.search_book(title)

        elif choice == "4":

            library.show_books()

        elif choice == "5":

            print("Exit...")
            break

        else:
            print("Not defind")
