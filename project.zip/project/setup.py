# -*- coding: utf-8 -*-
"""
Created on Mon May 11 12:41:37 2026

@author: e.nekoei
"""


from setuptools import setup, find_packages
setup(
    name="mylibrary",
    version="1.0.0",
    author="Elahe",
    description="A simple library management system",
    packages=find_packages()
)
